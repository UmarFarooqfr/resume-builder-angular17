import {
  AfterViewInit,
  Component,
  ElementRef,
  OnInit,
  ViewChild,
} from '@angular/core';
import { MaterialModule } from '../../../demo-material-module';
import { Router } from '@angular/router';
import { FormsModule } from '@angular/forms';
import * as jspdf from 'jspdf';
import html2canvas from 'html2canvas';
@Component({
  selector: 'app-resume-builder',
  standalone: true,
  imports: [MaterialModule, FormsModule],
  templateUrl: './resume-builder.component.html',
  styleUrl: './resume-builder.component.scss',
})
export class ResumeBuilderComponent implements OnInit, AfterViewInit {
  @ViewChild('content', { static: false }) content!: ElementRef;
  resumeValue: any = {
    resume: {
      profile: {
        name: '',
        summary:
          '',
        email: '',
        phone: '',
        location: '',
        url: '',
      },
      workExperiences: [
        {
          company: '',
          jobTitle: '',
          date: '',
          descriptions: [
          ],
        },
      ],
      educations: [
        {
          school: '',
          degree: '',
          gpa: '',
          date: '',
          descriptions: [
          ],
        },
      ],
      projects: [
        {
          project: '',
          date: '',
          descriptions: [
          ],
        },
      ],
      skills: {
        descriptions: [
        ],
      },
    },
  };
  constructor(private router: Router) {}
  ngOnInit(): void {
    
  }
  ngAfterViewInit() {
   
  }

  

  /**
   * autoResize
   * @param event 
   * @param id 
   * @param index 
   */
  autoResize(event: any, id: any, index: number) {
    console.log('id: ', id);
    const inputElement = event.target as HTMLElement;
    if (id === 'descriptionInput' + index) {
      this.resumeValue.resume.workExperiences[index].descriptions =
        inputElement.innerText
          .split('\n')
          .map((line) => line.trim())
          .filter((line) => line.length > 0);
    } else if (id === 'additionalInput' + index) {
      this.resumeValue.resume.educations[index].descriptions =
        inputElement.innerText
          .split('\n')
          .map((line) => line.trim())
          .filter((line) => line.length > 0);
    } else if (id === 'projectDescription' + index) {
      this.resumeValue.resume.projects[index].descriptions =
        inputElement.innerText
          .split('\n')
          .map((line) => line.trim())
          .filter((line) => line.length > 0);
    } else if (id === 'skillsInput' + index) {
      this.resumeValue.resume.skills.descriptions = inputElement.innerText
        .split('\n')
        .map((line) => line.trim())
        .filter((line) => line.length > 0);
    }
    console.log('inputElement.innerText ', inputElement.innerText);
    const elemnt: any = document.getElementById(id);
    elemnt.style.height = 'auto';
    elemnt.style.height = elemnt.scrollHeight + 'px';
  }

  /**
   * addNew
   * @param value 
   */
  addNew(value: any) {
    let firstWorkExperience = this.resumeValue.resume[value][0];
    let newWorkExperience: any = {};
    for (let key in firstWorkExperience) {
      if (firstWorkExperience.hasOwnProperty(key)) {
        newWorkExperience[key] = key === 'descriptions' ? [] : '';
      }
    }
    this.resumeValue.resume[value].push(newWorkExperience);
  }
  /**
   * exportToPDF
   */
  exportToPDF() {
    const element: any = document.getElementById('content');
  
    const originalOverflow = element.style.overflow;
    const originalHeight = element.style.height;
  
    element.style.overflow = 'visible'; 
    element.style.height = 'auto'; 
  
    const scrollHeight = element.scrollHeight;
    const windowHeight = window.innerHeight; 
    const scale = windowHeight / scrollHeight;
  
    html2canvas(element, {
      scale: 8, 
      scrollY: -window.scrollY,
      windowWidth: document.documentElement.offsetWidth,
      windowHeight: document.documentElement.offsetHeight,
    }).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jspdf.jsPDF();
  
      const imgProps = pdf.getImageProperties(imgData);
      const pdfWidth = pdf.internal.pageSize.getWidth();
      const pdfHeight = (imgProps.height * pdfWidth) / imgProps.width;
  
      pdf.addImage(imgData, 'PNG', 0, 0, pdfWidth, pdfHeight);
      pdf.save('filename.pdf');
  
      // Restore original overflow and height styles
      element.style.overflow = originalOverflow;
      element.style.height = originalHeight;
    });
  }

  
 
}
