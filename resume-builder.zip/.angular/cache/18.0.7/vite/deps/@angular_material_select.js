import {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  matSelectAnimations
} from "./chunk-UTDADML2.js";
import {
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix
} from "./chunk-XFJC7UOU.js";
import "./chunk-MRI4E4VT.js";
import "./chunk-NTLI4KXB.js";
import "./chunk-2RF3YJ6Z.js";
import "./chunk-UFNPSOVB.js";
import "./chunk-TPKBY26H.js";
import "./chunk-TFQYW2KW.js";
import "./chunk-HE4EUMZY.js";
import {
  MatOptgroup,
  MatOption
} from "./chunk-GQCZ3WG6.js";
import "./chunk-HXCAFB7T.js";
import "./chunk-GMU3YORD.js";
import "./chunk-KETHBM2Q.js";
import "./chunk-237XUEJ5.js";
import "./chunk-GEUAQIFD.js";
import "./chunk-BA56F4BC.js";
import "./chunk-XHZSVX7W.js";
import "./chunk-TEAJFDC2.js";
import "./chunk-ASLTLD6L.js";
export {
  MAT_SELECT_CONFIG,
  MAT_SELECT_SCROLL_STRATEGY,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER,
  MAT_SELECT_SCROLL_STRATEGY_PROVIDER_FACTORY,
  MAT_SELECT_TRIGGER,
  MatError,
  MatFormField,
  MatHint,
  MatLabel,
  MatOptgroup,
  MatOption,
  MatPrefix,
  MatSelect,
  MatSelectChange,
  MatSelectModule,
  MatSelectTrigger,
  MatSuffix,
  matSelectAnimations
};
//# sourceMappingURL=@angular_material_select.js.map
