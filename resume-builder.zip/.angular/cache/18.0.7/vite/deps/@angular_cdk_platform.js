import {
  Platform,
  PlatformModule,
  RtlScrollAxisType,
  _getEventTarget,
  _getFocusedElementPierceShadowDom,
  _getShadowRoot,
  _isTestEnvironment,
  _supportsShadowDom,
  getRtlScrollAxisType,
  getSupportedInputTypes,
  normalizePassiveListenerOptions,
  supportsPassiveEventListeners,
  supportsScrollBehavior
} from "./chunk-BA56F4BC.js";
import "./chunk-XHZSVX7W.js";
import "./chunk-TEAJFDC2.js";
import "./chunk-ASLTLD6L.js";
export {
  Platform,
  PlatformModule,
  RtlScrollAxisType,
  _getEventTarget,
  _getFocusedElementPierceShadowDom,
  _getShadowRoot,
  _isTestEnvironment,
  _supportsShadowDom,
  getRtlScrollAxisType,
  getSupportedInputTypes,
  normalizePassiveListenerOptions,
  supportsPassiveEventListeners,
  supportsScrollBehavior
};
//# sourceMappingURL=@angular_cdk_platform.js.map
