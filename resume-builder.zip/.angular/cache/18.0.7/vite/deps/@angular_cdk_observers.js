import {
  CdkObserveContent,
  ContentObserver,
  MutationObserverFactory,
  ObserversModule
} from "./chunk-KETHBM2Q.js";
import "./chunk-GEUAQIFD.js";
import "./chunk-TEAJFDC2.js";
import "./chunk-ASLTLD6L.js";
export {
  CdkObserveContent,
  ContentObserver,
  MutationObserverFactory,
  ObserversModule
};
//# sourceMappingURL=@angular_cdk_observers.js.map
