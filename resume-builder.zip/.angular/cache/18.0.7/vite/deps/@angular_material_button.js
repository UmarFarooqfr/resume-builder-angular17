import {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
} from "./chunk-YD5IK7KP.js";
import "./chunk-GQCZ3WG6.js";
import "./chunk-HXCAFB7T.js";
import "./chunk-GMU3YORD.js";
import "./chunk-KETHBM2Q.js";
import "./chunk-237XUEJ5.js";
import "./chunk-GEUAQIFD.js";
import "./chunk-BA56F4BC.js";
import "./chunk-XHZSVX7W.js";
import "./chunk-TEAJFDC2.js";
import "./chunk-ASLTLD6L.js";
export {
  MAT_BUTTON_CONFIG,
  MAT_FAB_DEFAULT_OPTIONS,
  MAT_FAB_DEFAULT_OPTIONS_FACTORY,
  MatAnchor,
  MatButton,
  MatButtonModule,
  MatFabAnchor,
  MatFabButton,
  MatIconAnchor,
  MatIconButton,
  MatMiniFabAnchor,
  MatMiniFabButton
};
//# sourceMappingURL=@angular_material_button.js.map
