import {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
} from "./chunk-HBMNRNMQ.js";
import "./chunk-NTLI4KXB.js";
import "./chunk-2RF3YJ6Z.js";
import "./chunk-UFNPSOVB.js";
import "./chunk-TPKBY26H.js";
import "./chunk-TFQYW2KW.js";
import "./chunk-GQCZ3WG6.js";
import "./chunk-HXCAFB7T.js";
import "./chunk-GMU3YORD.js";
import "./chunk-KETHBM2Q.js";
import "./chunk-237XUEJ5.js";
import "./chunk-GEUAQIFD.js";
import "./chunk-BA56F4BC.js";
import "./chunk-XHZSVX7W.js";
import "./chunk-TEAJFDC2.js";
import "./chunk-ASLTLD6L.js";
export {
  MAT_TOOLTIP_DEFAULT_OPTIONS,
  MAT_TOOLTIP_DEFAULT_OPTIONS_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY,
  MAT_TOOLTIP_SCROLL_STRATEGY_FACTORY_PROVIDER,
  MatTooltip,
  MatTooltipModule,
  SCROLL_THROTTLE_MS,
  TOOLTIP_PANEL_CLASS,
  TooltipComponent,
  getMatTooltipInvalidPositionError,
  matTooltipAnimations
};
//# sourceMappingURL=@angular_material_tooltip.js.map
