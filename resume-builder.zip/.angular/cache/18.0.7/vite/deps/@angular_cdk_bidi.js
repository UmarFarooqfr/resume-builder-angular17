import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-HXCAFB7T.js";
import "./chunk-XHZSVX7W.js";
import "./chunk-TEAJFDC2.js";
import "./chunk-ASLTLD6L.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
//# sourceMappingURL=@angular_cdk_bidi.js.map
