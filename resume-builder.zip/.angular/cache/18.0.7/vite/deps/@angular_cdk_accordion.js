import {
  CDK_ACCORDION,
  CdkAccordion,
  CdkAccordionItem,
  CdkAccordionModule
} from "./chunk-ZALK6HVB.js";
import "./chunk-TPKBY26H.js";
import "./chunk-TEAJFDC2.js";
import "./chunk-ASLTLD6L.js";
export {
  CDK_ACCORDION,
  CdkAccordion,
  CdkAccordionItem,
  CdkAccordionModule
};
//# sourceMappingURL=@angular_cdk_accordion.js.map
